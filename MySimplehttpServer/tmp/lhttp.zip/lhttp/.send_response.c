void send_response(int clientdesc, const char *buf)
{
    printf ( "response data: %s\n", buf ); 
}
